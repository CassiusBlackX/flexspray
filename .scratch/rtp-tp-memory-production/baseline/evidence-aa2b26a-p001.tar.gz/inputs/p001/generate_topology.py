#!/usr/bin/env python3
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO_ROOT / "scratch/ns-3-ub-tools"))
import net_sim_builder as netsim

graph = netsim.NetworkSimulationGraph()
graph.output_dir = str(Path(__file__).resolve().parent)
host_count, leaf_count, spine_count = 1024, 32, 32
for host_id in range(host_count):
    graph.add_netisim_host(host_id, forward_delay="1ns")
for leaf_id in range(host_count, host_count + leaf_count):
    graph.add_netisim_node(leaf_id, forward_delay="1ns")
for spine_id in range(host_count + leaf_count, host_count + leaf_count + spine_count):
    graph.add_netisim_node(spine_id, forward_delay="1ns")
for host_id in range(host_count):
    graph.add_netisim_edge(host_id, host_count + host_id // 32, bandwidth="400Gbps", delay="20ns", edge_count=1)
for leaf_id in range(host_count, host_count + leaf_count):
    for spine_id in range(host_count + leaf_count, host_count + leaf_count + spine_count):
        graph.add_netisim_edge(leaf_id, spine_id, bandwidth="400Gbps", delay="20ns", edge_count=1)
graph.build_graph_config()
graph.gen_2layer_clos_compressed_route_table(host_count, leaf_count)
graph.write_config(include_transport=False)

