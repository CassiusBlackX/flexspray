# p001 Experiment Spec

- Goal: one-phase 1024-host canary and fixed-topology RSS baseline.
- Topology: two-layer Clos, 1024 hosts, 32 leaves, 32 spines, 400 Gbps, 20 ns.
- Workload: first pairwise AllToAll phase, 1024 directed RTP WRITEs, 917504 bytes each.
- Transport channel mode: on-demand.
- Runtime: MTP 16, RNG run 1, deterministic 32 ps initial-task offset with seed 1, guarded at
  10 GiB RSS and 900 seconds.
- Evidence: task-only trace without post-processing plus process timing/RSS samples.
- Status: retry approved after the unshifted time-zero attempt hit an MTP bootstrap EventId assertion.
